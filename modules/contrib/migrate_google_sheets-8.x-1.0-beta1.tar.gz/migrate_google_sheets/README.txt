The migrate_google_sheets module provides a Migrate Plus data parser plugin for
Google Sheets.

Requirements
=======

The source Google Sheet will need to be published and viewable without authentication.

Examples
========
* The migrate_google_sheets_example submodule provides a fully functional and runnable
example migration scenario.