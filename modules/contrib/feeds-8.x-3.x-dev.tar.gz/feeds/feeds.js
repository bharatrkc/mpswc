Drupal.AjaxCommands.prototype.feedsHash = function (ajax, response, status) {

  "use strict";

  window.location.hash = response.hash;
};
