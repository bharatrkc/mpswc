<?php

namespace Drupal\Tests\feeds\Unit\Result;

use Drupal\feeds\Result\ParserResult;
use Drupal\Tests\feeds\Unit\FeedsUnitTestCase;

/**
 * @coversDefaultClass \Drupal\feeds\Result\ParserResult
 * @group feeds
 */
class ParserResultTest extends FeedsUnitTestCase {

  public function test() {

  }

}
