<?php

namespace Drupal\feeds;

use Drupal\Core\Entity\EntityViewBuilder;

/**
 * Render controller for feeds feed items.
 */
class FeedViewBuilder extends EntityViewBuilder {

}
