<?php

namespace Drupal\feeds\Exception;

/**
 * Thrown if a feed is empty to abort importing.
 */
class EmptyFeedException extends FeedsRuntimeException {}
