<?php

namespace Drupal\feeds\Exception;

/**
 * Thrown when Feeds can not obtain a lock.
 */
class LockException extends FeedsRuntimeException {}
