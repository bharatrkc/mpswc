<?php

namespace Drupal\feeds\Exception;

/**
 * Thrown if validation of a feed item fails.
 */
class ValidationException extends FeedsRuntimeException {}
